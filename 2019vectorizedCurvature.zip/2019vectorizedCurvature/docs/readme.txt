Software name: vectorizedCurvatures
Date: may 30th 2019
Contact person: Paavo Nevalainen, ptneva@utu.fi, Paavo.Nevalainen@gmail.com

Article title: Pattern recognition of earthquake-induced paleo liquefaction 
spreads and Pulju moraines from an airborne laser scanning derived digital 
elevation model

Authors: Maarit Middleton*, Jukka Heikkonen, Paavo Nevalainen, 
Eija Hyv�nen, and Raimo Sutinen

Instructions (only Linux and Windows systems are supported): 
1) install e.g. anaconda python 3 (versions 2.x do not work). 
2) install gnu octave
3) run the following shell xommands

3.1) cd code; python main.py ../z/S5232G.asc 16 
   - produces c/16/S5232G.k1 and c/16/S5232G.k2 files
   - to compare your files to mine, use some file diff tool to 
     files in c/16orig/ and c716/

3.2) python main.py ../z/S5232G.asc 8
     python main.py ../z/S5232G.asc 4
     python main.py ../z/S5232G.asc 2
   - you have now grids with grid lengths delta = 2,4,8 and 16 m

3.3) gnuOctave mainGnuO.m
   - visualizes local distributions of the selected locations 
   - approx. a square with approx 200 m side is sampled and 
     the curvature histogram vectorized to a local sample vector 
   - notes:
         . \kappa_1 color scale has been inverted
         . curvatures are scaled within a unit interval
         . the actual command line command may differ (or use 
           the interactive gnuOctave source file selection + execution)

3.4) matlab mainMatlab.m
   - same as above, except you can zoom in and keep selecting locations
   - the curvature bars are properly scaled
   - this functions properly only in Matlab, which is a commercial software

Comments: 
   -docs/ folder contains the cartographic snapshot of the example 
    area UTM ETRS-TM35FIN map page S5232G (6km x 6 km).  