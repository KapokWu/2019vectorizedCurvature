cplot= @(r,x0,y0) plot(x0 + r*cos(linspace(0,2*pi,30)),y0 + r*sin(linspace(0,2*pi,30)),'r-');
eps= 1.0e-4; % semilogy savior!

delta= input('Gimme the delta value [2,4,8,16] ');
if ~find([2,4,8,16] == delta)
    exit(0);
end
files= dir(sprintf('../c/%d/*.k1',delta));
f1= [files(1).folder,filesep,files(1).name]; kappa1= load(f1,'-ascii');
mapName= strsplit(files(1).name,'.'); mapName= mapName{1};
files= dir(sprintf('../c/%d/*.k2',delta));
f2= [files(1).folder,filesep,files(1).name]; kappa2= load(f2,'-ascii');
kappa2= load(f2,'-ascii'); sz= size(kappa2);

% plot the principal curvature layers
k1min= min(min(kappa1)); k1max= max(max(kappa1)); 
subplot(3,2,1); imshow(kappa1, [k1min,k1max]); 
h= colorbar; colormap(flipud(gray)); title(h, '(m^{-1})'); 
xlabel('E'); ylabel('N'); title([mapName,' \kappa_1 (m^{-1})']);

k2min= min(min(kappa2)); k2max= max(max(kappa2));
subplot(3,2,2); imshow(kappa2, [k2min,k2max]); 
xlabel('E'); ylabel('N'); title([mapName,' \kappa_2 (m^{-1})']);
h= colorbar; title(h, '(m^{-1})');

% plot the principal curvature distributions over the whole area
subplot(3,2,3);
    sz= size(kappa1); n= prod(sz); 
    [f1,x1]= hist(reshape(kappa1,n,1), 70); f1= f1/trapz(x1,f1);
    [f2,x2]= hist(reshape(kappa2,n,1), 70); f2= f2/trapz(x2,f2);
    xMin= min([x1,x2]); xMax= max([x1,x2]);
    fMin= min([f1,f2]); fMax= max([f1,f2]);

    semilogy(x1,f1+eps, 'k'); hold on;
    semilogy(x2,f2+eps, 'b'); axis([xMin,xMax,fMin,fMax]);
    xlabel('\kappa_1,\kappa_2 (m^{-1})'); ylabel('freq. (m)');
    title(sprintf('principal curvatures with delta=%.f (m)',delta));
    legend('\kappa_1','\kappa_2'); grid on; 

    subplot(3,2,5);
        scatter(reshape(kappa1,n,1),reshape(kappa2,n,1), '.');
        xlabel('\kappa_1 (m^{-1})'); ylabel('\kappa_2 (m^{-1})');
        title('principal curv. distrib. with delta=%.f (m)');
        axis equal; 

% plot local princ. curv. distributions
    goOn= 1;
    while goOn
        subplot(3,2,1);
            L1= get(gca,{'xlim','ylim'}); 
            disp('give a location on the kappa_1 plot');
            [x,y,~]= ginput(1); c= round([y,x]); r= 100.0; % sampling radius (m)
            r= round(r/delta); 
            
            hold off; 
            imshow(kappa1, [k1min,k1max]);
            h= colorbar; colormap(flipud(gray)); title(h, '(m^{-1})'); 
            xlabel('E'); ylabel('N'); title([mapName,' \kappa_1 (m^{-1})']);
            
            hold on; cplot(r,c(2),c(1));
            set(gca,{'xlim','ylim'},L1);
    
        subplot(3,2,2);
            L2= get(gca,{'xlim','ylim'}); 
            hold off; 
            imshow(kappa2, [k2min,k2max]);
            xlabel('E'); ylabel('N'); title([mapName,' \kappa_2 (m^{-1})']);
            h= colorbar; title(h, '(m^{-1})');

            hold on; cplot(r,c(2),c(1));
            set(gca,{'xlim','ylim'},L2);
            
        iInds= max(1,c(1)-r):min(sz(1),c(1)+r);
        jInds= max(1,c(2)-r):min(sz(2),c(2)+r);
        subKappa1= kappa1(iInds,jInds); subKappa2= kappa2(iInds,jInds);
        subSz= size(subKappa1); nSub= prod(subSz);

        nBins= min(70,max(round(sqrt(prod(subSz))/4),8));
        [f3,x3]= hist(reshape(subKappa1,nSub,1), nBins); f3= f3/trapz(x3,f3);
        [f4,x4]= hist(reshape(subKappa2,nSub,1), nBins); f4= f4/trapz(x4,f4);

        subplot(3,2,4);
            semilogy(x3,f3+eps, 'k'); hold on;
            semilogy(x4,f4+eps, 'b'); hold off; 
            xlabel('\kappa_1,\kappa_2 (m^{-1})'); ylabel('freq. (m)');
            title(sprintf('local princ. curvatures',delta));
            axis([xMin,xMax,fMin,fMax]); grid on; 

        subplot(3,2,6); 
            scatter(reshape(subKappa1,nSub,1),reshape(subKappa2,nSub,1), '.');
            axis equal; 
            xlabel('\kappa_1 (m^{-1})'); ylabel('\kappa_2 (m^{-1})');
            title('local princ. curv. distrib. with delta=%.f (m)');
            
        goOn= input('A new spot [0/1]? '); 
    end