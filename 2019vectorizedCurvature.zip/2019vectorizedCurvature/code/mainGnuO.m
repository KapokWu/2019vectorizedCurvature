cplot= @(r,x0,y0) plot(x0 + r*cos(linspace(0,2*pi,30)),y0 + r*sin(linspace(0,2*pi,30)),'r-');
eps= 1.0e-4; 

delta= input('Gimme the delta value [2,4,8,16] ');
if ~find([2,4,8,16] == delta)
    exit(0);
end
files= dir(sprintf('../c/%d/*.k1',delta));
f1= [files(1).folder,filesep,files(1).name]; kappa1= load(f1,'-ascii');
files= dir(sprintf('../c/%d/*.k2',delta));
f2= [files(1).folder,filesep,files(1).name]; kappa2= load(f2,'-ascii');
kappa2= load(f2,'-ascii'); sz= size(kappa2);

% plot the principal curvature layers
k1min= min(min(kappa1)); k1max= max(max(kappa1)); 
subplot(2,2,1); imshow(1.0-(kappa1-k1min)/(k1max-k1min)); 
title('\kappa_1 (m^{-1})'); colorbar;
k2min= min(min(kappa2)); k2max= max(max(kappa2));
subplot(2,2,2); imshow((kappa2-k2min)/(k2max-k2min)); 
title('\kappa_2 (m^{-1})'); colorbar;

% plot the principal curvature distributions over the whole area
subplot(2,2,3);
    [f1,x1]= hist(reshape(kappa1,prod(sz),1), 70); f1= f1/trapz(x1,f1);
    [f2,x2]= hist(reshape(kappa2,prod(sz),1), 70); f2= f2/trapz(x2,f2);
    sz= size(kappa1); xMin= min([x1,x2]); xMax= max([x1,x2]);
    fMin= min([f1,f2]); fMax= max([f1,f2]);

    hold off; semilogy(x1,f1+eps, 'k'); hold on;
    semilogy(x2,f2+eps, 'b'); axis([xMin,xMax,fMin,fMax]); grid on;
    xlabel('\kappa_1,\kappa_2 (m^{-1})'); ylabel('freq. (m)');
    title(sprintf('principal curvatures on delta=%.f (m)',delta));
    legend('\kappa_1','\kappa_2');

% plot local princ. curv. distributions
    goOn= 1;
    while goOn
        subplot(2,2,1); 
            disp('give a location on the kappa_1 plot');
            [x,y,~]= ginput(1); c= [x,y]; r= 100.0; % sampling radius (m)
            r= round(r/delta); c= round(c([2,1]));
            
            hold off; 
            imshow(1.0-(kappa1-k1min)/(k1max-k1min));
            hold on; cplot(r,c(2),c(1));
        subplot(2,2,2);
            hold off; 
            imshow((kappa2-k2min)/(k2max-k2min));
            hold on; cplot(r,c(2),c(1));
            
        iInds= max(1,c(1)-r):min(sz(1),c(1)+r);
        jInds= max(1,c(2)-r):min(sz(2),c(2)+r);
        subKappa1= kappa1(iInds,jInds); subKappa2= kappa2(iInds,jInds);
        subSz= size(subKappa1); 

        nBins= min(70,max(round(sqrt(prod(subSz))/4),8));
        [f3,x3]= hist(reshape(subKappa1,prod(subSz),1), nBins); f3= f3/trapz(x3,f3);
        [f4,x4]= hist(reshape(subKappa2,prod(subSz),1), nBins); f4= f4/trapz(x4,f4);

        subplot(2,2,4);
            semilogy(x3,f3+eps, 'k'); hold on;
            semilogy(x4,f4+eps, 'b'); grid on; hold off; 
            xlabel('\kappa_1,\kappa_2 (m^{-1})'); ylabel('freq. (m)');
            title(sprintf('local princ. curvatures',delta));
            axis([xMin,xMax,fMin,fMax]);

        goOn= input('A new spot [0/1]? '); 
    end